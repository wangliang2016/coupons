/** Automatically generated file. DO NOT MODIFY */
package com.alipay.android.msp.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}